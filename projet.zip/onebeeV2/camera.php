<?php
	// Permet d'afficher le flux vidéo de motion sur une page web.
	// N'oubliez pas de configurer l'adresse IP et le port correctement.

	<img alt="http://127.0.0.1:8081/" src="http://127.0.0.1:8081/">

?>
