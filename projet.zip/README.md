# openbee
# Version2
- ajout de l'Ajax sur les graphes
 - modif de la page d'acceuil
 - modif de la mise en page de flux
