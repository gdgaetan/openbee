 Vous vous trouvez dans le repertoire enregistrant les données sous un format csv. 
 Ces fichiers sont directement exportable vers Excel ou tout autre logiciel de traitement de ce type.
