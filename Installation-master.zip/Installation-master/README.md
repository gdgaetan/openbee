# Installation
Script d'installation du projet Onebee

Ce script vous permet d'installer la totalitée des bibliotheques utilisée dans ce projet.
il supporte la mise en place d'un réseau wifi racordable a internet.

Il execute aussi deux programmes:
  - Initialisation : permettant de remplir un fichier avec vos paramètres personnels (numero ruche, lieu et nom)
  - Le programme principal
  
Ce fichier met en place aussi, de facon automatique, le lancement du programme au démarrage de la raspberry.

Essentiellement, ce script permet de mettre en place l'environnement de travail et de tester une fois que tout a bien été mis en place.

Il ne restera plus qu'a brancher la raspberry a son module pour que son travail commence.

Ce document sera fréquement mis à jour. Et son répertoire doté de la version la plus récente du projet.
Ce dépôt est la pour effectuer une mise en place rapide de l'environnement 

